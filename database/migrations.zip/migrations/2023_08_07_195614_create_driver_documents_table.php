<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDriverDocumentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('driver_documents', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->foreignId('driver_id')->constrained(table:'drivers')->cascadeOnDelete();
            $table->text('front_img');
            $table->text('back_img');       
            $table->timestamps();
            $table->softDeletes();
            /**
             * Indexes
             */
            $table->index('driver_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('driver_documents');
    }
}
